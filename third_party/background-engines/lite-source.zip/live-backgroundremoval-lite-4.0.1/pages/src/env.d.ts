// SPDX-FileCopyrightText: 2025-2026 Kaito Udagawa <umireon@kaito.tokyo>
//
// SPDX-License-Identifier: Apache-2.0

interface ImportMetaEnv {
  readonly GITHUB_SHA?: string;
  readonly GITHUB_TOKEN?: string;
}
