<!--
SPDX-FileCopyrightText: 2025-2026 Kaito Udagawa <umireon@kaito.tokyo>

SPDX-License-Identifier: Apache-2.0
-->

# Contributing to Live Background Removal Lite

## Legal and Community Guidelines

To keep the Live Background Removal Lite project safe and reliable for everyone including its users, its contributors, and its maintainers, those who are involved in the development of this project must know the following terms. Whenever we receive your pull request (PR), we will explicitly ask you to confirm that it conforms to our policy.

### 1. Licensing and Patent Grant

- **Agreement**: You agree to distribute your contribution under the Apache License, Version 2.0, or the GNU General Public License v3.0 or later.
- **Appropriate License Selection**: You MUST choose an appropriate license for every file. If you are in doubt, please ask a maintainer of this project. A maintainer may ask you for another license than Apache License 2.0 or GPLv3.
- **Patent License**: For files licensed under Apache-2.0, refer to the [terms of Apache License 2.0 (Section 3)](https://www.apache.org/licenses/LICENSE-2.0#patent). For files licensed under GPL-3.0-or-later, refer to [terms of GNU GPLv3 (Section 11)](https://www.gnu.org/licenses/gpl-3.0.html#section11).

### 2. License Compliance

To ensure the transparency of our codebase, we require all code to be compliant with [REUSE](https://reuse.software/).

### 3. Code Integrity

We always welcome every contribution! To deliver the value of your work to our users in a professional manner, please adhere to the following policies:

- **No Unverified Code**: Do not submit any code that you cannot fully understand and explain. Submitting any raw outputs from LLMs or Generative-AI is strictly prohibited, except for translations.
- **Responsibility**: You must take responsibility for your code. Please ensure that your contribution has clean licensing and is reliable. We are here to help you accomplish this, of course!

### 4. Developer Certificate of Origin (DCO) and Commit Signing

Please sign off (-s) all your commits (DCO), and sign all your commits (-S) with your GPG or SSH key:

```
git commit -s -S
```

Please refer to https://developercertificate.org/ for DCO, and refer to the [GitHub documentation on commit signing](https://docs.github.com/authentication/managing-commit-signature-verification) for configuring commit signing.
