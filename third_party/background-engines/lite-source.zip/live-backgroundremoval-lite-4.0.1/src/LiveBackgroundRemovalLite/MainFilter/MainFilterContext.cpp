// SPDX-FileCopyrightText: 2025-2026 Kaito Udagawa <umireon@kaito.tokyo>
//
// SPDX-License-Identifier: GPL-3.0-or-later

#include "MainFilterContext.hpp"

#include <future>
#include <stdexcept>
#include <thread>

#include <QApplication>

#include <obs-module.h>
#include <obs-frontend-api.h>

#include <KaitoTokyo/ObsBridgeUtils/GsUnique.hpp>
#include <KaitoTokyo/ObsBridgeUtils/ObsLogger.hpp>
#include <KaitoTokyo/ObsBridgeUtils/ObsUnique.hpp>

#include <PluginConfigDialog.hpp>

#include "DebugWindow.hpp"
#include "RenderingContext.hpp"
#include "TroubleshootDialog.hpp"

using namespace KaitoTokyo::Logger;
using namespace KaitoTokyo::ObsBridgeUtils;

namespace KaitoTokyo::LiveBackgroundRemovalLite::MainFilter {

MainFilterContext::MainFilterContext(obs_data_t *settings, obs_source_t *source,
				     std::shared_ptr<Global::PluginConfig> pluginConfig,
				     std::shared_ptr<Global::GlobalContext> globalContext)
	: source_{source ? source
			 : throw std::invalid_argument("SourceIsNullError(MainFilterContext::MainFilterContext)")},
	  pluginConfig_{pluginConfig ? std::move(pluginConfig)
				     : throw std::invalid_argument(
					       "PluginConfigIsNullError(MainFilterContext::MainFilterContext)")},
	  globalContext_{globalContext ? std::move(globalContext)
				       : throw std::invalid_argument(
						 "GlobalContextIsNullError(MainFilterContext::MainFilterContext)")},
	  logger_(globalContext_->getLogger()
			  ? globalContext_->getLogger()
			  : throw std::invalid_argument("LoggerIsNullError(MainFilterContext::MainFilterContext)")),
	  mainEffect_(logger_, unique_obs_module_file("effects/main.effect")),
	  selfieSegmenterTaskQueue_(logger_, 1)
{
	update(settings);
}

void MainFilterContext::shutdown() noexcept
{
	{
		std::lock_guard<std::mutex> lock(debugWindowMutex_);
		if (debugWindow_) {
			try {
				debugWindow_->close();
			} catch (...) {
				// Ignore
			}
		}
	}

	{
		std::lock_guard<std::mutex> lock(renderingContextMutex_);
		renderingContext_.reset();
	}
	selfieSegmenterTaskQueue_.shutdown();
}

MainFilterContext::~MainFilterContext() noexcept {}

std::uint32_t MainFilterContext::getWidth() const noexcept
{
	auto renderingContext = getRenderingContext();
	return renderingContext ? renderingContext->region_.width : 0;
}

std::uint32_t MainFilterContext::getHeight() const noexcept
{
	auto renderingContext = getRenderingContext();
	return renderingContext ? renderingContext->region_.height : 0;
}

void MainFilterContext::getDefaults(obs_data_t *data)
{
	PluginProperty defaultProperty;

	obs_data_set_default_int(data, "filterLevel", static_cast<int>(defaultProperty.filterLevel));

	obs_data_set_default_double(data, "motionIntensityThresholdPowDb",
				    defaultProperty.motionIntensityThresholdPowDb);

	obs_data_set_default_double(data, "timeAveragedFilteringAlpha", defaultProperty.timeAveragedFilteringAlpha);

	obs_data_set_default_bool(data, "advancedSettings", false);

	obs_data_set_default_double(data, "guidedFilterEpsPowDb", defaultProperty.guidedFilterEpsPowDb);

	obs_data_set_default_int(data, "blurSize", defaultProperty.blurSize);

	obs_data_set_default_double(data, "maskGamma", defaultProperty.maskGamma);
	obs_data_set_default_double(data, "maskLowerBoundAmpDb", defaultProperty.maskLowerBoundAmpDb);
	obs_data_set_default_double(data, "maskUpperBoundMarginAmpDb", defaultProperty.maskUpperBoundMarginAmpDb);
}

obs_properties_t *MainFilterContext::getProperties()
{
	obs_property_t *pDesc;

	obs_properties_t *props = obs_properties_create();

	// Update notifier
	if (pluginConfig_->isAutoCheckForUpdateEnabled()) {
		const char *updateAvailableText = obs_module_text("updateCheckerCheckingError");
		try {
			std::optional<std::string> latestVersionOpt = globalContext_->getLatestVersion();
			if (!latestVersionOpt.has_value()) {
				updateAvailableText = obs_module_text("updateCheckerPending");
			} else if (latestVersionOpt.value() == globalContext_->getPluginVersion()) {
				updateAvailableText = obs_module_text("updateCheckerPluginIsLatest");
			} else {
				updateAvailableText = obs_module_text("updateCheckerUpdateAvailable");
			}
		} catch (const std::exception &e) {
			logger_->error("CheckUpdateExceptionError", {{"message", e.what()}});
		} catch (...) {
			logger_->error("CheckUpdateUnknownExceptionError");
		}
		pDesc = obs_properties_add_text(props, "isUpdateAvailable", updateAvailableText, OBS_TEXT_INFO);
		obs_property_text_set_info_word_wrap(pDesc, false);
	}

	// Having trouble? button
	obs_property_clicked_t havingTroubleCallback = [](obs_properties_t *, obs_property_t *, void *) {
		TroubleshootDialog dialog(QApplication::activeWindow());
		dialog.setWindowModality(Qt::WindowModal);
		dialog.exec();
		return false;
	};

	obs_properties_add_button2(props, "havingTroubleButton", obs_module_text("havingTroubleButton"),
				   havingTroubleCallback, nullptr);

	pDesc = obs_properties_add_text(props, "separatorAfterHavingTroubleButton", "<hr />", OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	// Filter level
	pDesc = obs_properties_add_text(props, "filterLevelDescription", obs_module_text("filterLevelDescription"),
					OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	obs_property_t *propFilterLevel =
		obs_properties_add_list(props, "filterLevel", "", OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_INT);
	obs_property_list_add_int(propFilterLevel, obs_module_text("filterLevelDefault"),
				  static_cast<int>(FilterLevel::Default));
	obs_property_list_add_int(propFilterLevel, obs_module_text("filterLevelPassthrough"),
				  static_cast<int>(FilterLevel::Passthrough));
	obs_property_list_add_int(propFilterLevel, obs_module_text("filterLevelSegmentation"),
				  static_cast<int>(FilterLevel::Segmentation));
	obs_property_list_add_int(propFilterLevel, obs_module_text("filterLevelMotionIntensityThresholding"),
				  static_cast<int>(FilterLevel::MotionIntensityThresholding));
	obs_property_list_add_int(propFilterLevel, obs_module_text("filterLevelGuidedFilter"),
				  static_cast<int>(FilterLevel::GuidedFilter));
	obs_property_list_add_int(propFilterLevel, obs_module_text("filterLevelTimeAveragedFilter"),
				  static_cast<int>(FilterLevel::TimeAveragedFilter));

	pDesc = obs_properties_add_text(props, "filterLevelDescription400",
					obs_module_text("filterLevelDescription400"), OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	pDesc = obs_properties_add_text(props, "filterLevelDescription500",
					obs_module_text("filterLevelDescription500"), OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	pDesc = obs_properties_add_text(props, "separatorAfterFilterLevel", "<hr />", OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	// Motion intensity threshold
	pDesc = obs_properties_add_text(props, "motionIntensityThresholdPowDbDescription",
					obs_module_text("motionIntensityThresholdPowDbDescription"), OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	obs_properties_add_float_slider(props, "motionIntensityThresholdPowDb", "", -100.0, 0.0, 0.1);

	pDesc = obs_properties_add_text(props, "separatorAfterMotionIntensityThreshold", "<hr />", OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	// Time-averaged filtering
	pDesc = obs_properties_add_text(props, "timeAveragedFilteringAlphaDescription",
					obs_module_text("timeAveragedFilteringAlphaDescription"), OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	obs_properties_add_float_slider(props, "timeAveragedFilteringAlpha", "", 0.0f, 1.0f, 0.01f);

	pDesc = obs_properties_add_text(props, "separatorAfterTimeAveragedFilteringAlpha", "<hr />", OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);

	// Blur size
	pDesc = obs_properties_add_text(props, "blurSizeDescription", obs_module_text("blurSizeDescription"),
					OBS_TEXT_INFO);
	obs_property_text_set_info_word_wrap(pDesc, false);
	obs_properties_add_int_slider(props, "blurSize", "", 0, 10, 1);

	// Advanced settings group
	obs_properties_t *propsAdvancedSettings = obs_properties_create();
	obs_properties_add_group(props, "advancedSettings", obs_module_text("advancedSettings"), OBS_GROUP_CHECKABLE,
				 propsAdvancedSettings);

	// Guided filter
	obs_properties_add_float_slider(propsAdvancedSettings, "guidedFilterEpsPowDb",
					obs_module_text("guidedFilterEpsPowDb"), -60.0, -20.0, 0.1);

	// Mask application
	obs_properties_add_float_slider(propsAdvancedSettings, "maskGamma", obs_module_text("maskGamma"), 0.5, 3.0,
					0.01);
	obs_properties_add_float_slider(propsAdvancedSettings, "maskLowerBoundAmpDb",
					obs_module_text("maskLowerBoundAmpDb"), -80.0, -10.0, 0.1);
	obs_properties_add_float_slider(propsAdvancedSettings, "maskUpperBoundMarginAmpDb",
					obs_module_text("maskUpperBoundMarginAmpDb"), -80.0, -10.0, 0.1);

	// Global config dialog button
	obs_properties_add_button2(
		props, "openGlobalConfigDialog", obs_module_text("openGlobalConfigDialog"),
		[](obs_properties_t *, obs_property_t *, void *data) {
			MainFilterContext *self = static_cast<MainFilterContext *>(data);
			if (!self)
				return false;

			Global::PluginConfigDialog dialog(self->pluginConfig_, self->globalContext_,
							  QApplication::activeWindow());
			dialog.setWindowModality(Qt::WindowModal);
			dialog.exec();
			return false;
		},
		this);

	// Debug button
	obs_properties_add_button2(
		props, "showDebugWindow", obs_module_text("showDebugWindow"),
		[](obs_properties_t *, obs_property_t *, void *data) {
			auto this_ = static_cast<MainFilterContext *>(data);
			DebugWindow *windowToShow = nullptr;

			{
				std::lock_guard<std::mutex> lock(this_->debugWindowMutex_);
				if (this_->debugWindow_) {
					windowToShow = this_->debugWindow_;
				} else {
					auto parent = static_cast<QWidget *>(obs_frontend_get_main_window());
					auto newDebugWindow = new DebugWindow(this_->weak_from_this(), parent);

					newDebugWindow->setAttribute(Qt::WA_DeleteOnClose);

					QObject::connect(newDebugWindow, &QDialog::finished,
							 [newDebugWindow, weakSelf = this_->weak_from_this()](int) {
								 if (auto self = weakSelf.lock()) {
									 std::lock_guard<std::mutex> lock(
										 self->debugWindowMutex_);
									 if (self->debugWindow_ == newDebugWindow) {
										 self->debugWindow_ = nullptr;
									 }
								 }
							 });
					windowToShow = newDebugWindow;
					this_->debugWindow_ = newDebugWindow;
				}
			}

			if (windowToShow) {
				windowToShow->show();
				windowToShow->raise();
				windowToShow->activateWindow();
			}

			return false;
		},
		this);

	return props;
}

void MainFilterContext::update(obs_data_t *settings)
{
	bool doesRenewRenderingContext = false;
	PluginProperty newPluginProperty = pluginProperty_;

	newPluginProperty.filterLevel = static_cast<FilterLevel>(obs_data_get_int(settings, "filterLevel"));

	newPluginProperty.motionIntensityThresholdPowDb =
		obs_data_get_double(settings, "motionIntensityThresholdPowDb");

	newPluginProperty.timeAveragedFilteringAlpha = obs_data_get_double(settings, "timeAveragedFilteringAlpha");

	bool advancedSettingsEnabled = obs_data_get_bool(settings, "advancedSettings");
	if (advancedSettingsEnabled) {
		newPluginProperty.guidedFilterEpsPowDb = obs_data_get_double(settings, "guidedFilterEpsPowDb");

		newPluginProperty.maskGamma = obs_data_get_double(settings, "maskGamma");
		newPluginProperty.maskLowerBoundAmpDb = obs_data_get_double(settings, "maskLowerBoundAmpDb");
		newPluginProperty.maskUpperBoundMarginAmpDb =
			obs_data_get_double(settings, "maskUpperBoundMarginAmpDb");
	}

	int newBlurSize = obs_data_get_int(settings, "blurSize");

	if (newPluginProperty.blurSize != newBlurSize) {
		newPluginProperty.blurSize = newBlurSize;
		doesRenewRenderingContext = true;
	}

	std::shared_ptr<RenderingContext> renderingContext;
	{
		std::lock_guard<std::mutex> lock(renderingContextMutex_);

		pluginProperty_ = newPluginProperty;
		renderingContext = renderingContext_;

		if (renderingContext && doesRenewRenderingContext) {
			GraphicsContextGuard graphicsContextGuard;
			std::shared_ptr<RenderingContext> newRenderingContext = createRenderingContext(
				renderingContext->region_.width, renderingContext->region_.height, newBlurSize);
			renderingContext_ = newRenderingContext;
			renderingContext = newRenderingContext;
			GsUnique::drain();
		}
	}

	if (renderingContext) {
		renderingContext->applyPluginProperty(pluginProperty_);
	}
}

void MainFilterContext::activate()
{
	if (renderingContext_) {
		renderingContext_->activate();
	}
}

void MainFilterContext::deactivate()
{
	if (renderingContext_) {
		renderingContext_->deactivate();
	}
}

void MainFilterContext::show()
{
	if (renderingContext_) {
		renderingContext_->show();
	}
}

void MainFilterContext::hide()
{
	if (renderingContext_) {
		renderingContext_->hide();
	}
}

void MainFilterContext::videoTick(float seconds)
{
	obs_source_t *const parent = obs_filter_get_parent(source_);
	if (!parent) {
		logger_->debug("NoParentSourceFound");
		return;
	} else if (!obs_source_active(parent)) {
		logger_->debug("ParentSourceNotActive");
		return;
	}

	obs_source_t *const target = obs_filter_get_target(source_);
	if (!target) {
		logger_->debug("NoTargetSourceFound");
		return;
	}

	uint32_t targetWidth = obs_source_get_base_width(target);
	uint32_t targetHeight = obs_source_get_base_height(target);

	std::shared_ptr<RenderingContext> renderingContext;
	{
		std::lock_guard<std::mutex> lock(renderingContextMutex_);

		if (targetWidth == 0 || targetHeight == 0) {
			logger_->debug("TargetSourceHasZeroWidthOrHeight");
			renderingContext_.reset();
			return;
		}

		const std::uint32_t minSize = 2 * static_cast<std::uint32_t>(pluginProperty_.subsamplingRate);
		if (targetWidth < minSize || targetHeight < minSize) {
			logger_->debug("TargetSourceTooSmall");
			renderingContext_.reset();
			return;
		}

		renderingContext = renderingContext_;
		if (!renderingContext || renderingContext->region_.width != targetWidth ||
		    renderingContext->region_.height != targetHeight) {
			GraphicsContextGuard graphicsContextGuard;
			renderingContext_ = createRenderingContext(targetWidth, targetHeight, pluginProperty_.blurSize);
			GsUnique::drain();
			renderingContext = renderingContext_;
		}
	}

	if (renderingContext) {
		renderingContext->videoTick(seconds);
	}
}

void MainFilterContext::videoRender()
{
	obs_source_t *const parent = obs_filter_get_parent(source_);
	if (!parent) {
		logger_->debug("NoParentSourceFound");
		// Draw nothing to prevent unexpected background disclosure
		return;
	} else if (!obs_source_active(parent)) {
		logger_->debug("ParentSourceNotActive");
		// Draw nothing to prevent unexpected background disclosure
		return;
	} else if (!obs_source_showing(parent)) {
		logger_->debug("ParentSourceNotShowing");
		// Draw nothing to prevent unexpected background disclosure
		return;
	}

	if (auto _renderingContext = getRenderingContext()) {
		_renderingContext->videoRender();
	}

	{
		std::lock_guard<std::mutex> lock(debugWindowMutex_);

		if (debugWindow_) {
			debugWindow_->videoRender();
		}
	}
}

std::shared_ptr<RenderingContext> MainFilterContext::createRenderingContext(std::uint32_t targetWidth,
									    std::uint32_t targetHeight, int blurSize)
{
	auto renderingContext = std::make_shared<RenderingContext>(source_, logger_, mainEffect_,
								   selfieSegmenterTaskQueue_, pluginConfig_,
								   pluginProperty_.subsamplingRate, targetWidth,
								   targetHeight, pluginProperty_.numThreads, blurSize);

	renderingContext->applyPluginProperty(pluginProperty_);

	return renderingContext;
}

} // namespace KaitoTokyo::LiveBackgroundRemovalLite::MainFilter
