// SPDX-FileCopyrightText: 2025-2026 Kaito Udagawa <umireon@kaito.tokyo>
//
// SPDX-License-Identifier: GPL-3.0-or-later

#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>

#ifdef PREFIXED_NCNN_HEADERS
#include <ncnn/net.h>
#else
#include <net.h>
#endif

#include <KaitoTokyo/Logger/ILogger.hpp>
#include <KaitoTokyo/Memory/MemoryBlockPool.hpp>
#include <KaitoTokyo/ObsBridgeUtils/AsyncTextureReader.hpp>
#include <KaitoTokyo/ObsBridgeUtils/GsUnique.hpp>
#include <KaitoTokyo/SelfieSegmenter/ISelfieSegmenter.hpp>
#include <KaitoTokyo/TaskQueue/ThrottledTaskQueue.hpp>

#include "MainEffect.hpp"
#include "PluginConfig.hpp"
#include "PluginProperty.hpp"

namespace KaitoTokyo::LiveBackgroundRemovalLite::MainFilter {

struct RenderingContextRegion {
	std::uint32_t x;
	std::uint32_t y;
	std::uint32_t width;
	std::uint32_t height;
};

class RenderingContext : public std::enable_shared_from_this<RenderingContext> {
private:
	[[nodiscard]]
	ObsBridgeUtils::unique_gs_texture_t makeTexture(std::uint32_t width, std::uint32_t height,
							enum gs_color_format color_format,
							std::uint32_t flags) const noexcept;

	[[nodiscard]]
	RenderingContextRegion getMaskRoiPosition() const noexcept;

	[[nodiscard]]
	std::vector<ObsBridgeUtils::unique_gs_texture_t> createReductionPyramid(std::uint32_t width,
										std::uint32_t height) const;

	[[nodiscard]]
	std::vector<ObsBridgeUtils::unique_gs_texture_t>
	createDualKawasePyramid(std::uint32_t width, std::uint32_t height, int blurSize) const;

public:
	RenderingContext(obs_source_t *const source, std::shared_ptr<const Logger::ILogger> logger,
			 const MainEffect &mainEffect, TaskQueue::ThrottledTaskQueue &selfieSegmenterTaskQueue,
			 std::shared_ptr<Global::PluginConfig> pluginConfig, const std::uint32_t subsamplingRate,
			 const std::uint32_t width, const std::uint32_t height, const int numThreads, int blurSize);
	~RenderingContext() noexcept;

	void activate();
	void deactivate();
	void show();
	void hide();

	void videoTick(float);
	void videoRender();

	void applyPluginProperty(const PluginProperty &pluginProperty);

	std::uint32_t getWidth() const noexcept { return region_.width; }
	std::uint32_t getHeight() const noexcept { return region_.height; }

private:
	obs_source_t *const source_;
	const std::shared_ptr<const Logger::ILogger> logger_;
	const MainEffect &mainEffect_;
	TaskQueue::ThrottledTaskQueue &selfieSegmenterTaskQueue_;
	const std::shared_ptr<Global::PluginConfig> pluginConfig_;

public:
	const std::uint32_t subsamplingRate_;
	const int numThreads_;
	const int blurSize_;

	std::unique_ptr<SelfieSegmenter::ISelfieSegmenter> selfieSegmenter_;
	std::shared_ptr<Memory::MemoryBlockPool> selfieSegmenterMemoryBlockPool_;
	bool hasNewSegmenterInput_ = false;
	std::atomic<bool> hasNewSegmentationMask_ = false;

	const RenderingContextRegion region_;
	const RenderingContextRegion subRegion_;
	const RenderingContextRegion subPaddedRegion_;
	const RenderingContextRegion maskRoi_;

	const ObsBridgeUtils::unique_gs_texture_t bgrxSource_;
	const ObsBridgeUtils::unique_gs_texture_t r32fLuma_;

	const std::array<ObsBridgeUtils::unique_gs_texture_t, 2> r32fSubLumas_;
	std::size_t currentSubLumaIndex_ = 0;

	const ObsBridgeUtils::unique_gs_texture_t r32fSubPaddedSquaredMotion_;
	const std::vector<ObsBridgeUtils::unique_gs_texture_t> r32fMeanSquaredMotionReductionPyramid_;
	ObsBridgeUtils::AsyncTextureReader r32fReducedMeanSquaredMotionReader_;

	RenderingContextRegion segmenterRoi_;

	const ObsBridgeUtils::unique_gs_texture_t bgrxSegmenterInput_;
	ObsBridgeUtils::AsyncTextureReader bgrxSegmenterInputReader_;

	std::vector<std::uint8_t> segmenterInputBuffer_;

	const ObsBridgeUtils::unique_gs_texture_t r8SegmentationMask_;

	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFIntermediate_;

	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFSource_;
	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFMeanGuide_;
	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFMeanSource_;
	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFMeanGuideSource_;
	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFMeanGuideSq_;
	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFA_;
	const ObsBridgeUtils::unique_gs_texture_t r32fSubGFB_;
	const ObsBridgeUtils::unique_gs_texture_t r8GuidedFilterResult_;

	const std::array<ObsBridgeUtils::unique_gs_texture_t, 2> r8TimeAveragedMasks_;
	std::size_t currentTimeAveragedMaskIndex_ = 0;

	const std::vector<ObsBridgeUtils::unique_gs_texture_t> bgrxDualKawaseBlurReductionPyramid_;

private:
	std::atomic<FilterLevel> filterLevel_;

	std::atomic<float> motionIntensityThreshold_;

	std::atomic<float> guidedFilterEps_;

	std::atomic<float> maskGamma_;
	std::atomic<float> maskLowerBound_;
	std::atomic<float> maskUpperBoundMargin_;

	std::atomic<float> timeAveragedFilteringAlpha_;

	std::atomic<bool> shouldNextVideoRenderProcessFrame_ = true;
	std::atomic<bool> shouldNextVideoRenderForceProcessFrame_ = true;
};

} // namespace KaitoTokyo::LiveBackgroundRemovalLite::MainFilter
