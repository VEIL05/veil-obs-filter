// SPDX-FileCopyrightText: 2025-2026 Kaito Udagawa <umireon@kaito.tokyo>
//
// SPDX-License-Identifier: GPL-3.0-or-later

#pragma once

#ifdef __APPLE__
#include <jthread.hpp>
#endif

#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>

#include <KaitoTokyo/CurlHelper/CurlHandle.hpp>
#include <KaitoTokyo/Logger/ILogger.hpp>

#include "PluginConfig.hpp"

namespace KaitoTokyo::LiveBackgroundRemovalLite::Global {

#ifdef __APPLE__
namespace jthread_ns = josuttis;
#else
namespace jthread_ns = std;
#endif

class GlobalContext : public std::enable_shared_from_this<GlobalContext> {
public:
	GlobalContext(std::shared_ptr<PluginConfig> pluginConfig, std::shared_ptr<const Logger::ILogger> logger,
		      std::string pluginName, std::string pluginVersion, std::string latestVersionUrl);

	~GlobalContext() noexcept;

	std::string getPluginName() const noexcept;
	std::string getPluginVersion() const noexcept;
	std::string getQtResourcePrefix() const noexcept;
	std::shared_ptr<const Logger::ILogger> getLogger() const noexcept;
	std::optional<std::string> getLatestVersion() const;

	void checkForUpdates();

private:
	const std::string pluginName_;
	const std::string pluginVersion_;
	const std::shared_ptr<const Logger::ILogger> logger_;
	const std::string latestVersionUrl_;
	const std::shared_ptr<PluginConfig> pluginConfig_;

	mutable std::mutex mutex_;
	CurlHelper::CurlHandle curl_;

	std::optional<std::string> latestVersion_{std::nullopt};
	jthread_ns::jthread fetchLatestVersionThread_;

	static void fetchLatestVersionThread(jthread_ns::stop_token stoken, std::shared_ptr<GlobalContext> self);
};

} // namespace KaitoTokyo::LiveBackgroundRemovalLite::Global
