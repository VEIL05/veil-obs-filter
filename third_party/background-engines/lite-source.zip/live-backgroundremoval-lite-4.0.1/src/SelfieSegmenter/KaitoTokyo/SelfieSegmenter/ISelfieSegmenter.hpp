// SPDX-FileCopyrightText: 2025-2026 Kaito Udagawa <umireon@kaito.tokyo>
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <mutex>
#include <vector>

namespace KaitoTokyo::SelfieSegmenter {

class ISelfieSegmenter {
protected:
	ISelfieSegmenter() = default;

public:
	virtual ~ISelfieSegmenter() = default;

	virtual std::size_t getWidth() const noexcept = 0;
	virtual std::size_t getHeight() const noexcept = 0;
	virtual std::size_t getPixelCount() const noexcept = 0;

	virtual void process(const std::uint8_t *bgraData) = 0;

	virtual const std::uint8_t *getMask() const = 0;

	ISelfieSegmenter(const ISelfieSegmenter &) = delete;
	ISelfieSegmenter &operator=(const ISelfieSegmenter &) = delete;
	ISelfieSegmenter(ISelfieSegmenter &&) = delete;
	ISelfieSegmenter &operator=(ISelfieSegmenter &&) = delete;
};

} // namespace KaitoTokyo::SelfieSegmenter
