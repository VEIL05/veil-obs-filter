// SPDX-FileCopyrightText: 2025-2026 Kaito Udagawa <umireon@kaito.tokyo>
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <new>
#include <vector>

#include <KaitoTokyo/Logger/ILogger.hpp>

#include "AlignedAllocator.hpp"

namespace KaitoTokyo::Memory {

/**
 * @class MemoryBlockPool
 * @brief A thread-safe memory pool for fixed-size, aligned memory blocks.
 *
 * This pool manages a collection of memory blocks of a specific size and alignment.
 * It uses std::shared_ptr with a custom deleter to automatically return blocks
 * to the pool when they are no longer in use.
 *
 * The pool's lifecycle is managed by std::enable_shared_from_this, ensuring that
 * blocks can be safely returned to the pool (or freed if the pool is destroyed)
 * even if the pool instance itself is destroyed while blocks are still in use.
 */
class MemoryBlockPool : public std::enable_shared_from_this<MemoryBlockPool> {
	using BlockType = std::vector<std::uint8_t, AlignedAllocator<std::uint8_t>>;

public:
	/**
	 * @brief A shared pointer to a memory block acquired from the pool.
	 *
	 * When this pointer goes out of scope, the underlying memory block is
	 * automatically returned to the pool (if the pool still exists and is not full)
	 * or deallocated.
	 */
	using MemoryBlockSharedPtr = std::shared_ptr<BlockType>;

	/**
	 * @brief Factory function to create a new MemoryBlockPool instance.
	 *
	 * As the constructor is private, this function must be used to create the pool.
	 *
	 * @param logger The instance of ILogger for logging purposes.
	 * @param blockSize The size (in bytes) of each memory block. Must be greater than 0
	 * and a multiple of alignment.
	 * @param maxSize The maximum number of idle blocks to keep in the pool.
	 * Must be greater than 0. Defaults to 32.
	 *
	 * @throw std::invalid_argument If any of the parameters (blockSize, alignment, maxSize)
	 * do not meet the specified requirements.
	 *
	 * @return A std::shared_ptr to the newly created MemoryBlockPool.
	 */
	static std::shared_ptr<MemoryBlockPool> create(std::shared_ptr<const Logger::ILogger> logger,
						       std::size_t blockSize, std::size_t alignment = 32,
						       std::size_t maxSize = 32)
	{
		if (blockSize == 0) {
			throw std::invalid_argument("blockSize must be greater than 0");
		} else if (maxSize == 0) {
			throw std::invalid_argument("maxSize must be greater than 0");
		}
		return std::shared_ptr<MemoryBlockPool>(new MemoryBlockPool(logger, blockSize, alignment, maxSize));
	}

	/**
	 * @brief Destroys the memory pool.
	 *
	 * All idle blocks currently held in the pool are deallocated.
	 * Any blocks that are still in use (acquired via acquire()) will be
	 * safely deallocated when their respective shared_ptr instances go out of scope,
	 * without attempting to return them to the now-destroyed pool.
	 */
	~MemoryBlockPool() noexcept {}

	/**
	 * @brief Acquires a memory block from the pool.
	 *
	 * If the pool has an idle block available, it is returned.
	 * If the pool is empty, a new block is allocated with the specified
	 * size and alignment.
	 *
	 * @return A MemoryBlockSharedPtr (a shared_ptr) managing the acquired block.
	 * When this pointer goes out of scope, the block is automatically
	 * returned to the pool or deallocated.
	 */
	MemoryBlockSharedPtr acquire()
	{
		std::unique_ptr<BlockType> block;
		{
			std::lock_guard<std::mutex> lock(poolMutex_);
			if (pool_.empty()) {
				block = std::make_unique<BlockType>(blockSize_,
								    AlignedAllocator<std::uint8_t>(alignment_));
			} else {
				block = std::move(pool_.back());
				pool_.pop_back();
			}
		}

		auto *blockPtr = block.get();

		return MemoryBlockSharedPtr(blockPtr,
					    [self = shared_from_this(), block = std::move(block)](BlockType *) mutable {
						    std::lock_guard<std::mutex> lock(self->poolMutex_);
						    if (self->pool_.size() < self->maxSize_) {
							    self->pool_.push_back(std::move(block));
						    }
					    });
	}

	/**
	 * @brief Gets the size of the memory blocks managed by this pool.
	 * @return The size (in bytes) of each block.
	 */
	std::size_t getPixelCount() const noexcept { return blockSize_; }

private:
	MemoryBlockPool(const std::shared_ptr<const Logger::ILogger> logger, std::size_t blockSize,
			std::size_t alignment, std::size_t maxSize)
		: logger_(std::move(logger)),
		  blockSize_(blockSize),
		  alignment_(alignment),
		  maxSize_(maxSize)
	{
	}

	const std::shared_ptr<const Logger::ILogger> logger_;
	std::size_t blockSize_;
	std::size_t alignment_;
	std::size_t maxSize_;
	std::vector<std::unique_ptr<BlockType>> pool_;
	mutable std::mutex poolMutex_;
};

} // namespace KaitoTokyo::Memory
